int my_tcp_connect(const char *host_name, int port, int *sd, int timeout) 
{ return OK; }

int my_sendall(int s, const char *buf, int *len, int timeout) 
{ return OK; }

int my_recvall(int s, char *buf, int *len, int timeout) 
{ return OK; }
